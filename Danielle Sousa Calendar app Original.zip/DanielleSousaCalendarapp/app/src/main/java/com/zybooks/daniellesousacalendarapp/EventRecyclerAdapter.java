package com.zybooks.daniellesousacalendarapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

//recycler view for displaying events
public class EventRecyclerAdapter extends RecyclerView.Adapter<EventRecyclerAdapter.ViewHolder> {

    //List to store events
    private final List<Event> Data;

    //inflate items layout
    private final LayoutInflater Inflater;

    //Click Listener for item clicks
    private ItemClickListener ClickListener;


    //returns view holder for each item
    EventRecyclerAdapter(Context context, List<Event> data) {
        this.Inflater = LayoutInflater.from(context);
        this.Data = data;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        // inflate layout for an event item
        View view = Inflater.inflate(R.layout.activity_event, parent, false);
        return new ViewHolder(view);
    }

    // get event at the specific position
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Event event = Data.get(position);

        // set event title and date to text views
        holder.EventName.setText(event.getTitle());
        holder.EventDate.setText(event.getFormattedDate());

    }

    // return nuber of items in the database
    @Override
    public int getItemCount() {

        return Data.size();
    }

    // view holder that has an single event item
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {


        //user interface for event details
        TextView EventName, EventDate;

        //the view of a single event
        ViewHolder(View itemView) {
            super(itemView);

            //initializes text views with user interface elements
            EventName = itemView.findViewById(R.id.eventName);
            EventDate = itemView.findViewById(R.id.eventDate);
            itemView.setOnClickListener(this);
        }



        //handles onClick events
        @Override
        public void onClick(View view) {
            if (ClickListener != null) {
                //Get clicked event
                Event clickedEvent = getEvent(getAdapterPosition());
                //callback with clicked event
                ClickListener.onItemClick(view, getAdapterPosition(), clickedEvent);
            }
        }
    }

    //event at a given position
   public Event getEvent (int position) {
        return Data.get(position);
   }

   //sets ClickListener for item clicks
    void setClickListener(ItemClickListener itemClickListener) {
        this.ClickListener = itemClickListener;
    }

    //handling item click events
    public interface ItemClickListener {
        void onItemClick(View view, int position, Event event);
    }
}