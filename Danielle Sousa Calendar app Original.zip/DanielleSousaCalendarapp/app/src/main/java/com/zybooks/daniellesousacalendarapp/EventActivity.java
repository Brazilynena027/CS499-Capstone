package com.zybooks.daniellesousacalendarapp;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;


import java.util.Calendar;
import java.util.List;
import java.util.ArrayList;
import android.content.Intent;


//displays list of events in recycler view
public class EventActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);

        //initializes recycler view
        RecyclerView mRecyclerView = findViewById(R.id.recyclerView);
        Context mContext = this;

        //get a list of events
        List<Event> mEvents = getEventList();

        //sets up recycler view adapter
        EventRecyclerAdapter mAdapter = new EventRecyclerAdapter(mContext, mEvents);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mRecyclerView.setAdapter(mAdapter);

        // handles event clicks
        mAdapter.setClickListener((view, position, event) -> {

            String eventTitle = event.getTitle();
            String eventDate = event.getFormattedDate();

            // intent to open event detail screen
            Intent intent = new Intent(mContext, Event.class);
            intent.putExtra("eventId", event.getId());
            intent.putExtra("eventTitle", eventTitle);
            intent.putExtra("eventDate", eventDate);

            startActivity(intent);

        });
    }

     // list of events with dates
    private List<Event> getEventList() {
        List<Event> events = new ArrayList<>();


        //sample events
        Calendar calendar1 = Calendar.getInstance();
        calendar1.set(2025, Calendar.JANUARY, 15);
        events.add(new Event(1, "Event 1", calendar1, "Description of Event 1", "user1"));

        Calendar calendar2 = Calendar.getInstance();
        calendar2.set(2025, Calendar.FEBRUARY, 22);
        events.add(new Event(2, "Event 2", calendar2, "Description of Event 2", "user2"));

        Calendar calendar3 = Calendar.getInstance();
        calendar3.set(2025, Calendar.MARCH, 7);
        events.add(new Event(3, "Event 3", calendar3, "Description of Event 3", "user3"));

        return events;
    }
}









