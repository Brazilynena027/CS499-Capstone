package com.zybooks.daniellesousacalendarapp;
// Create a DateUtil class For date formatting.

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;


//handles SQL Lite database for managing user and event info
public class EventDatabase extends SQLiteOpenHelper {

    //database name
    static final String DATABASE_NAME = "events_database";

    //database version
    private static final int VERSION = 1;

    //instance of database
    private static EventDatabase mEventDb;

    //logger for debug
    private static final Logger logger = Logger.getLogger(EventDatabase.class.getName());



    // single instance of database
    public static EventDatabase getInstance(Context context) {
        if (mEventDb == null) {
            mEventDb = new EventDatabase(context);
        }
        return mEventDb;
    }

    //constructor
    public EventDatabase(Context context) {

        super(context, DATABASE_NAME, null, VERSION);
    }

    // schema for storing user data
    private static final class UserTable {
        private static final String TABLE_USERS = "users";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_SMS_PERM = "smsPerm";
    }

    //schema for storing event data
    private static final class EventTable {
        private static final String TABLE_EVENTS = "events";
        private static final String COL_ID = "_id";
        private static final String COL_TITLE = "title";
        private static final String COL_DATE = "date";
        private static final String COL_DESCRIPTION = "description";
        private static final String COL_EVENT_NAME = "eventname";
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        // Creating user table
        db.execSQL("create table " + UserTable.TABLE_USERS + " (" +
                UserTable.COL_USERNAME + " primary key, " +
                UserTable.COL_PASSWORD + " text, " +
                UserTable.COL_SMS_PERM + " integer)");

        // Creating event table
        db.execSQL("create table " + EventTable.TABLE_EVENTS + " (" +
                EventTable.COL_ID + " integer primary key autoincrement, " +
                EventTable.COL_TITLE + " text, " +
                EventTable.COL_DATE + " integer, " +
                EventTable.COL_DESCRIPTION + " text, " +
                EventTable.COL_EVENT_NAME + " text, " +
                "foreign key(" + EventTable.COL_EVENT_NAME + ") references " +
                UserTable.TABLE_USERS + "(" + UserTable.COL_USERNAME + ") on delete cascade)");

        // Adding administrator for testing
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, "admin");
        values.put(UserTable.COL_PASSWORD, "1234");
        values.put(UserTable.COL_SMS_PERM, "3");
        db.insert(UserTable.TABLE_USERS, null, values);
    }

    //upgrades the database that drops an existing table and recreates them
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + EventTable.TABLE_EVENTS);
        onCreate(db);
    }

    // enable foreign key constraints
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }



    // retrieves a user by username
    public User getUser(String username) {
        SQLiteDatabase db = getWritableDatabase();
        String sql = " SELECT * FROM " + UserTable.TABLE_USERS
                + " WHERE " + UserTable.COL_USERNAME + " = '" + username +"'";

        Cursor cursor = db.rawQuery(sql, null);
        User user = new User();
        if (cursor.moveToFirst()) {
            do {
                user.setUsername(cursor.getString(0));
                user.setPassword(cursor.getString(1));
                user.setSmsBool(cursor.getInt(2));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return user;
    }

    // add a new user to database
    public void addUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, user.getUsername());
        values.put(UserTable.COL_PASSWORD, user.getPassword());
        values.put(UserTable.COL_SMS_PERM, 3);
        try {
            db.insertOrThrow(UserTable.TABLE_USERS, null, values);
        } catch (SQLiteConstraintException e) {
            // Handle constraint violation (e.g., duplicate username)
            Log.e("UserDatabase", "Error inserting user " + e.getMessage());
        }
    }

    //authenticates a user
    public boolean authenticateUser(User user) {
        SQLiteDatabase db = this.getReadableDatabase();
        final String USERNAME = user.getUsername();
        final String PASSWORD = user.getPassword();

        String sql = "SELECT * FROM " + UserTable.TABLE_USERS
                + " WHERE " + UserTable.COL_USERNAME + " = ?";


        try (Cursor cursor = db.rawQuery(sql, new String[]{USERNAME})) {
            if (cursor.moveToFirst()) {
                String storedPassword = cursor.getString(cursor.getColumnIndexOrThrow(UserTable.COL_PASSWORD));
                return storedPassword.equals(PASSWORD);
            } else {
                return false;
            }
        }
    }

    // registers a user for a new account
    public boolean registerUser(User user) {
        SQLiteDatabase db = this.getReadableDatabase();
        final String USERNAME = user.getUsername();

        if (!USERNAME.isEmpty()) {
            String sql = "SELECT " + UserTable.COL_USERNAME + " FROM " + UserTable.TABLE_USERS
                    + " WHERE " + UserTable.COL_USERNAME + " = ?";

            try (Cursor cursor = db.rawQuery(sql, new String[]{USERNAME})) {
                if (cursor.moveToFirst()) {
                    return false;
                } else {
                    this.addUser(user);
                    return true;
                }
            }
        } else {
            return false;
        }
    }

    // get list of events
    public List<Event> getEvents(String username) {
        List<Event> events = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        // Define the columns you want to retrieve
        String[] projection = {
                EventTable.COL_ID,
                EventTable.COL_TITLE,
                EventTable.COL_DATE,
                EventTable.COL_DESCRIPTION,
                EventTable.COL_EVENT_NAME
        };

        // Define the selection criteria
        String selection = EventTable.COL_EVENT_NAME + " = ?";
        String[] selectionArgs = {username};

        // Specify the sort order
        final String orderBy = EventTable.COL_DATE + " ASC";

        // Table name
        // Columns to retrieve
        // WHERE clause
        // Values for WHERE clause
        // GROUP BY
        // HAVING
        // ORDER BY

        try (Cursor cursor = db.query(
                EventTable.TABLE_EVENTS, // Table name
                projection, // Columns to retrieve
                selection, // WHERE clause
                selectionArgs, // Values for WHERE clause
                null, // GROUP BY
                null, // HAVING
                orderBy // ORDER BY
        )) {
            if (cursor.moveToFirst()) {
                do {
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow(EventTable.COL_ID));
                    String title = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COL_TITLE));
                    long timestamp = cursor.getLong(cursor.getColumnIndexOrThrow(EventTable.COL_DATE));
                    Calendar date = timestampToCalendar(timestamp);
                    String description = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COL_DESCRIPTION));
                    String eventUsername = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COL_EVENT_NAME));

                    Event event = new Event( id,title, date, description, eventUsername);
                    events.add(event);
                } while (cursor.moveToNext());
            }
        }
        // Always close the cursor to release resources

        return events;
    }
    //FIX ME: Refactor to DateUtil class
    private Calendar timestampToCalendar(long timestamp) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(timestamp);
        return cal;
    }



    //retrieves events for a user
    public Event getEvent(int eId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Event event = new Event();

        String sql = "select * from " + EventTable.TABLE_EVENTS +
                " where " + EventTable.COL_ID + " = " + eId;

        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                event.setId(cursor.getInt(0));
                event.setTitle(cursor.getString(1));
                Calendar cal = formatDate(cursor.getLong(2));
                event.setDate(cal);
                event.setDescription(cursor.getString(3));
                event.setEventusername(cursor.getString(4));
            } while (cursor.moveToNext());
        }
        cursor.close();

        return event;
    }


    // add an event for a user
    public void addEvent(Event event) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        // https://chatgpt.com/
        // FIX ME: refactor code format event date to a string using DateUtils
        // String formattedDate = DateUtils.formatEventDate(event.getDate());
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm", Locale.US); // Delete Line
        String formattedDate = dateFormat.format(event.getDate().getTime());

        values.put(EventTable.COL_TITLE, event.getTitle());
        values.put(EventTable.COL_DATE, Long.parseLong(formattedDate));
        values.put(EventTable.COL_DESCRIPTION, event.getDescription());
        values.put(EventTable.COL_EVENT_NAME, event.getEventusername());

        try {
            long id = db.insert(EventTable.TABLE_EVENTS, null, values);
            event.setId(Math.toIntExact(id));
        } catch (Exception e) {
            logger.log(Level.SEVERE, "An error occurred while adding an event", e);
        }
    }


    // update an event for a user
    public boolean updateEvent(Event event) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        // https://chatgpt.com/
        // FIX ME: Refactor to use DateUtil class
        // String formattedDate = DateUtils.formatEventDate(event.getDate());
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm", Locale.US);
        String formattedDate = dateFormat.format(event.getDate().getTime());

        values.put(EventTable.COL_ID, event.getId());
        values.put(EventTable.COL_TITLE, event.getTitle());
        values.put(EventTable.COL_DATE, Long.parseLong(formattedDate));
        values.put(EventTable.COL_DESCRIPTION, event.getDescription());
        values.put(EventTable.COL_EVENT_NAME, event.getEventusername());

        try {
            db.update(EventTable.TABLE_EVENTS, values,
                    EventTable.COL_ID + " = ?", new String[]{Integer.toString(event.getId())});
            return true;
        } catch (Exception e) {
            logger.log(Level.SEVERE, "An error occurred while updating an event", e);
            return false;
        }
    }


    // delete an event for a user
    public void deleteEvent(Event event) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(EventTable.TABLE_EVENTS,
                EventTable.COL_ID + " = ?", new String[] { Integer.toString(event.getId()) });
    }

    // Once the date conversion logic is in place in the DateUtils class helper this can be deleted.
    public Calendar formatDate(long longDate) {
        String sDate = Long.toString(longDate);
        int iYear = Integer.parseInt(sDate.substring(0, 4));
        int iMonth = Integer.parseInt(sDate.substring(4, 6)) - 1;
        int iDay = Integer.parseInt(sDate.substring(6, 8));
        int iHour = Integer.parseInt(sDate.substring(8, 10));
        int iMinute = Integer.parseInt(sDate.substring(10, 12));
        Calendar cal = Calendar.getInstance();
        cal.set(iYear, iMonth, iDay, iHour, iMinute);
        return cal;
    }
}