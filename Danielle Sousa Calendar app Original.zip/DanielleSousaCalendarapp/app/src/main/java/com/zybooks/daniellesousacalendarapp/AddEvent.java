package com.zybooks.daniellesousacalendarapp;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



import java.util.Calendar;

//add new event to calendar
public class AddEvent extends AppCompatActivity {

    // store events in database
    private EventDatabase mEventDb;

    //stores logged in username
    private String mUsername;

    // user interface elements event input
    private EditText mTitle;
    private EditText mYear;
    private EditText mMonth;
    private EditText mDay;
    private EditText mHour;
    private EditText mMinute;
    private EditText mDescription;

    //string date and time inputs
    private String sYear;
    private String sMonth;
    private String sDay;
    private String sHour;
    private String sMinute;

    //integer date and time inputs
    private int iYear;
    private int iMonth;
    private int iDay;
    private int iHour;
    private int iMinute;

    //store selected date
    private Calendar mUserDate;


    // initializes user interface components
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_event);

        //get username from activity
        Intent intent = getIntent();
        mUsername = intent.getStringExtra("authUsername");
        mEventDb = new EventDatabase(this);

        //initializes user interface elements
        mTitle = findViewById(R.id.eventTitle);
        mTitle.addTextChangedListener(new GenericTextWatcher(mTitle));
        mYear = findViewById(R.id.eventYear);
        mYear.addTextChangedListener(new GenericTextWatcher(mYear));
        mMonth = findViewById(R.id.eventMonth);
        mMonth.addTextChangedListener(new GenericTextWatcher(mMonth));
        mDay = findViewById(R.id.eventDay);
        mDay.addTextChangedListener(new GenericTextWatcher(mDay));
        mHour = findViewById(R.id.eventHour);
        mHour.addTextChangedListener(new GenericTextWatcher(mHour));
        mMinute = findViewById(R.id.eventMinute);
        mMinute.addTextChangedListener(new GenericTextWatcher(mMinute));
        mDescription = findViewById(R.id.eventDescription);
        mDescription.addTextChangedListener(new GenericTextWatcher(mDescription));
        Button mAddButton = findViewById(R.id.eventAddSubmit);
        Button mCancelButton = findViewById(R.id.eventCancelSubmit);

        mAddButton.setOnClickListener(this::addEvent);

        mCancelButton.setOnClickListener(this::cancelAddEvent);

    }

    //Add events to database
    public void addEvent(View view) {
        if (isEmpty(mTitle) && isValidDate() && isEmpty(mDescription)) {
            Event event = new Event(mTitle.getText().toString(), mUserDate, mDescription.getText().toString(), mUsername);
            mEventDb.addEvent(event);
            finish();
        }
    }

    // cancels event that is being created
    public void cancelAddEvent(View view) {
        finish();
    }

    // verifies edit text field is empty
    public boolean isEmpty(EditText editText) {
        String eToString = editText.getText().toString();
        return !eToString.matches("");
    }

    // Checking each numbers length of range
    public boolean isValidDate() {
        Calendar systemTime = Calendar.getInstance();

        if (sYear.length() != 4) {
            Toast myToast = Toast.makeText(this, "Invalid year. (4 digits)", Toast.LENGTH_SHORT);
            myToast.show();
            return false;
        }
        if (sMonth.length() > 2 || iMonth > 12 || iMonth < 1) {
            Toast myToast = Toast.makeText(this, "Invalid month. (1 - 12)", Toast.LENGTH_SHORT);
            myToast.show();
            return false;
        }
        if (sDay.length() > 2 || iDay > 31 || iDay < 1) {
            Toast myToast = Toast.makeText(this, "Invalid day. (1 - 31)", Toast.LENGTH_SHORT);
            myToast.show();
            return false;
        }
        if (sHour.length() > 2 || iHour > 23 || iHour < 1) {
            Toast myToast = Toast.makeText(this, "Invalid hour. (1 - 23)", Toast.LENGTH_SHORT);
            myToast.show();
            return false;
        }
        if (sMinute.length() > 2 || iMinute > 59 || iMinute < 1) {
            Toast myToast = Toast.makeText(this, "Invalid minute. (1 - 59)", Toast.LENGTH_SHORT);
            myToast.show();
            return false;
        }

        Calendar userDate = Calendar.getInstance();
        userDate.set(iYear, iMonth - 1, iDay, iHour, iMinute);
        // Checking if entered date is in the past
        if (userDate.getTimeInMillis() < systemTime.getTimeInMillis()) {
            Toast myToast = Toast.makeText(this, "Date cannot be before now.", Toast.LENGTH_SHORT);
            myToast.show();
            return false;
        }
        mUserDate = userDate;
        Toast myToast = Toast.makeText(this, "Event added: " + mTitle.getText().toString(), Toast.LENGTH_SHORT);
        myToast.show();
        return true;
    }

    //  constant updates on fields
    private class GenericTextWatcher implements TextWatcher {
        private final View view;
        private GenericTextWatcher(View view) {
            this.view = view;
        }

        public void afterTextChanged(Editable editable) {

            int viewId = view.getId();

            if (viewId == R.id.eventTitle) {
                mTitle = findViewById(R.id.eventTitle);
            } else if (viewId == R.id.eventYear) {
                mYear = findViewById(R.id.eventYear);
                sYear = mYear.getText().toString();
                iYear = convertStringtoInt(sYear);
            } else if (viewId == R.id.eventYear) {
                mYear = findViewById(R.id.eventYear);
                sYear = mYear.getText().toString();
                iYear = convertStringtoInt(sYear);
            } else if (viewId == R.id.eventMonth) {
                mMonth = findViewById(R.id.eventMonth);
                sMonth = mMonth.getText().toString();
                iMonth = convertStringtoInt(sMonth);
            } else if (viewId == R.id.eventDay) {
                mDay = findViewById(R.id.eventDay);
                sDay = mDay.getText().toString();
                iDay = convertStringtoInt(sDay);
            } else if (viewId == R.id.eventHour) {
                mHour = findViewById(R.id.eventHour);
                sHour = mHour.getText().toString();
                iHour = convertStringtoInt(sHour);
            } else if (viewId == R.id.eventMinute) {
                mMinute = findViewById(R.id.eventMinute);
                sMinute = mMinute.getText().toString();
                iMinute = convertStringtoInt(sMinute);
            } else if (viewId == R.id.eventDescription) {
                mDescription = findViewById(R.id.eventDescription);
            }
        }

        //
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

        private int convertStringtoInt(String string) {
            try {
                return Integer.parseInt(string);
            } catch(Exception e) {
                return 0;
            }
        }
    }
}