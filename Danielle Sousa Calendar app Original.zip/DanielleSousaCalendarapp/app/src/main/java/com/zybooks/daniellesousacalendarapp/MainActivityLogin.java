package com.zybooks.daniellesousacalendarapp;



import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.util.Log;
import android.widget.Toast;


//handles login functionality and user authentication
public class MainActivityLogin extends AppCompatActivity {


    private EventDatabase mEventDb;

    //user interface components for user input to enter username
    private EditText mUsername;

    //user interface components for user input to enter password
    private EditText mPassword;

    //authentication error message
    private TextView mAuthError;

    //interaction with login button
    private Button mLoginButton;

    // interaction with register button
    private Button mRegisterButton;

    //stores username
    private String regName;

    // interaction with checkbox
    private CheckBox mRememberMe;

    // stores user login preferences
    private SharedPreferences sharedPref;

    //key for storing user preferences
    private static final String PREFS_NAME = "UserPrefs";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_login);

        mEventDb = EventDatabase.getInstance(getApplicationContext());

        //initializes user interface components
        mUsername = findViewById(R.id.username);
        mPassword = findViewById(R.id.password);
        mAuthError = findViewById(R.id.errorText);
        mLoginButton = findViewById(R.id.login);
        mRegisterButton = findViewById(R.id.signup);
        TextView forgotPassword = findViewById(R.id.ForgotPassword);
        mRememberMe = findViewById(R.id.RememberMe);

        //verifies if remember me was checked previously
        sharedPref = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        boolean rememberMe = sharedPref.getBoolean("rememberMe", false);

        // if remember is checked then populate username and password
        if (rememberMe) {
            mUsername.setText(sharedPref.getString("username", ""));
            mPassword.setText(sharedPref.getString("password", ""));
            mRememberMe.setChecked(true);

        }

        // handles the result from register activity.
        ActivityResultLauncher<Intent> startRegistration = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            regName = data.getStringExtra("regUsername");
                            if (regName != null) {
                                navigateToCalendar(regName);
                            }
                        }
                    }
                }
        );


        mLoginButton.setOnClickListener(v -> authUser());

        // Launches Register activity if signup button press
        mRegisterButton.setOnClickListener(v -> {
            // add comment
            Log.d("MainActivityLogin", "Signup button clicked");
            Intent intent = new Intent(MainActivityLogin.this, RegisterActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startRegistration.launch(intent);
        });


        forgotPassword.setOnClickListener(v -> {

            Intent intent = new Intent(MainActivityLogin.this, ForgotPasswordActivity.class);
            startActivity(intent);
        });

    }


    // Checking if user password is correct in Database.
    public void authUser() {

        mAuthError.setVisibility(View.INVISIBLE);
        String username = mUsername.getText().toString().trim();
        String password = mPassword.getText().toString().trim();

        //verifies if username is empty
        if (username.isEmpty() || password.isEmpty()) {
            mAuthError.setText(R.string.username_and_password_cannot_be_blank);
            mAuthError.setVisibility(View.VISIBLE);
            return;
        }

        boolean authenticated;
        try {
            User user = new User(username, password);
            authenticated = mEventDb.authenticateUser(user);

        } catch (Exception e) {
            Log.e("MainActivityLogin", "Database authentication error", e);
            Toast.makeText(this, "Database error. Try Again", Toast.LENGTH_SHORT).show();
            return;
        }

        // if authentication fails
        if (!authenticated) {
            mAuthError.setText(R.string.invalid_username_or_password);
            mAuthError.setVisibility(View.VISIBLE);

        } else {
            savesUserPreferences(username, password);
            navigateToCalendar(username);
        }
    }

    //saves user preferences
    private void savesUserPreferences(String username, String password) {

            SharedPreferences.Editor editor = sharedPref.edit();
            if (mRememberMe.isChecked()) {
                editor.putBoolean("rememberMe", true);
                editor.putString("username", username);
                editor.putString("password", password);

            } else {

                editor.remove("rememberMe");
                editor.remove("username");
                editor.remove("password");

            }
            editor.apply();
        }

        //Navigate to calendar activity
        private void navigateToCalendar(String username) {
        Log.d("MainActivityLogin", "Navigating to CalendarActivity with user: " + username);
        Intent intent = new Intent(this, CalendarActivity.class);
        intent.putExtra("authUsername", username);
        startActivity(intent);
        finish();

        }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        mLoginButton.setOnClickListener(null);
        mRegisterButton.setOnClickListener(null);
    }
}





