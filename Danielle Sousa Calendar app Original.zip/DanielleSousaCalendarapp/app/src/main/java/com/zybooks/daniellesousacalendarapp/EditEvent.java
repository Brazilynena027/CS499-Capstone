package com.zybooks.daniellesousacalendarapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class EditEvent extends AppCompatActivity {

    //variables for interacting with events database and user interface components
    private EventDatabase mEventDb;
    private int mPassedId;
    private Event mEvent;
    private EditText mTitle;
    private EditText mYear;
    private EditText mMonth;
    private EditText mDay;
    private EditText mHour;
    private EditText mMinute;
    private EditText mDescription;
    private String sYear;
    private String sMonth;
    private String sDay;
    private String sHour;
    private String sMinute;
    private int iYear;
    private int iMonth;
    private int iDay;
    private int iHour;
    private int iMinute;
    private Calendar mUserDate;

    //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event);

        //get event ID and is passed through intent
        Intent intent = getIntent();
        mPassedId = intent.getIntExtra("eventId", -1);
        mEventDb = EventDatabase.getInstance(getApplicationContext());
        mEvent = mEventDb.getEvent(mPassedId);

        //initializes edit text fields and set the values

        //sets title from event
        mTitle = findViewById(R.id.eventTitle);
        mTitle.setText(mEvent.getTitle());
        mTitle.addTextChangedListener(new EditEvent.GenericTextWatcher(mTitle));

        //sets year
        mYear = findViewById(R.id.eventYear);
        mYear.setText(String.valueOf(mEvent.getDate().get(Calendar.YEAR)));
        mYear.addTextChangedListener(new EditEvent.GenericTextWatcher(mYear));

        //sets month
        mMonth = findViewById(R.id.eventMonth);
        mMonth.setText(String.valueOf(mEvent.getDate().get(Calendar.MONTH) + 1));
        mMonth.addTextChangedListener(new EditEvent.GenericTextWatcher(mMonth));

        //sets day
        mDay = findViewById(R.id.eventDay);
        mDay.setText(String.valueOf(mEvent.getDate().get(Calendar.DAY_OF_MONTH)));
        mDay.addTextChangedListener(new EditEvent.GenericTextWatcher(mDay));

        //sets hour
        mHour = findViewById(R.id.eventHour);
        mHour.setText(String.valueOf(mEvent.getDate().get(Calendar.HOUR_OF_DAY)));
        mHour.addTextChangedListener(new EditEvent.GenericTextWatcher(mHour));

        //sets minute
        mMinute = findViewById(R.id.eventMinute);
        mMinute.setText(String.valueOf(mEvent.getDate().get(Calendar.MINUTE)));
        mMinute.addTextChangedListener(new EditEvent.GenericTextWatcher(mMinute));

        //sets description
        mDescription = findViewById(R.id.eventDescription);
        mDescription.setText(mEvent.getDescription());
        mDescription.addTextChangedListener(new EditEvent.GenericTextWatcher(mDescription));

        //string variables for date and time to integers
        sYear = mYear.getText().toString();
        iYear = convertStringToInt(sYear);

        sMonth = mMonth.getText().toString();
        iMonth = convertStringToInt(sMonth);

        sDay = mDay.getText().toString();
        iDay = convertStringToInt(sDay);

        sHour = mHour.getText().toString();
        iHour = convertStringToInt(sHour);

        sMinute = mMinute.getText().toString();
        iMinute = convertStringToInt(sMinute);
    }

    //submit updated event info
    public void submitUpdate(View view) {
        if (isEmpty(mTitle) && isValidDate(mYear, mMonth, mDay, mHour, mMinute) && isEmpty(mDescription)) {
            Event event = new Event(mPassedId, mTitle.getText().toString(), mUserDate,
                    mDescription.getText().toString(), mEvent.getEventusername());
            if (!mEventDb.updateEvent(event)) {
                Toast myToast = Toast.makeText(this, "An error occurred with the update...", Toast.LENGTH_SHORT);
                myToast.show();
            }
            finish();
        }
    }

    //cancel update to event
    public void cancelUpdate(View view) {
        finish();
    }

    public boolean isEmpty(EditText editText) {
        String eToString = editText.getText().toString();
        return !eToString.matches("");
    }

    //validates date from user
    public boolean isValidDate(EditText sYear, EditText sMonth, EditText sDay, EditText sHour, EditText sMinute) {
        Calendar systemTime = Calendar.getInstance();

        // validates year
        if (sYear.length() != 4) {
            Toast myToast = Toast.makeText(this, "Invalid year. (4 digits)", Toast.LENGTH_SHORT);
            myToast.show();
            return false;
        }
        //validates month
        if (sMonth.length() > 2 || iMonth > 12 || iMonth < 1) {
            Toast myToast = Toast.makeText(this, "Invalid month. (1 - 12)", Toast.LENGTH_SHORT);
            myToast.show();
            return false;
        }
        // validates day
        if (sDay.length() > 2 || iDay > 31 || iDay < 1) {
            Toast myToast = Toast.makeText(this, "Invalid day. (1 - 31)", Toast.LENGTH_SHORT);
            myToast.show();
            return false;
        }
        //validates hour
        if (sHour.length() > 2 || iHour > 23 || iHour < 1) {
            Toast myToast = Toast.makeText(this, "Invalid hour. (1 - 23)", Toast.LENGTH_SHORT);
            myToast.show();
            return false;
        }
        //validates minutes
        if (sMinute.length() > 2 || iMinute > 59 || iMinute < 1) {
            Toast myToast = Toast.makeText(this, "Invalid minute. (1 - 59)", Toast.LENGTH_SHORT);
            myToast.show();
            return false;
        }

        // validates future event date
        Calendar userDate = Calendar.getInstance();
        userDate.set(iYear, iMonth, iDay, iHour, iMinute);

        if (userDate.getTimeInMillis() < systemTime.getTimeInMillis()) {
            Toast myToast = Toast.makeText(this, "Date cannot be before now.", Toast.LENGTH_SHORT);
            myToast.show();
            return false;
        }
        // store user date
        mUserDate = userDate;
        Toast myToast = Toast.makeText(this, "Event added: " + mTitle.getText().toString(), Toast.LENGTH_SHORT);
        myToast.show();
        return true;
    }

    // looks for changes in input fields
    private class GenericTextWatcher implements TextWatcher {
        private final View view;

        private GenericTextWatcher(View view) {
            this.view = view;
        }

        //After text changes
        public void afterTextChanged(Editable editable) {
            int viewId = view.getId();

            // update fields with changes
            if (viewId == R.id.eventTitle) {
                mTitle = findViewById(R.id.eventTitle);
            } else if (viewId == R.id.eventYear) {
                mYear = findViewById(R.id.eventYear);
                sYear = mYear.getText().toString();
                iYear = convertStringToInt(sYear);
            } else if (viewId == R.id.eventMonth) {
                mMonth = findViewById(R.id.eventMonth);
                sMonth = mMonth.getText().toString();
                iMonth = convertStringToInt(sMonth);
            } else if (viewId == R.id.eventDay) {
                mDay = findViewById(R.id.eventDay);
                sDay = mDay.getText().toString();
                iDay = convertStringToInt(sDay);
            } else if (viewId == R.id.eventHour) {
                mHour = findViewById(R.id.eventHour);
                sHour = mHour.getText().toString();
                iHour = convertStringToInt(sHour);
            } else if (viewId == R.id.eventMinute) {
                mMinute = findViewById(R.id.eventMinute);
                sMinute = mMinute.getText().toString();
                iMinute = convertStringToInt(sMinute);
            } else if (viewId == R.id.eventDescription) {
                mDescription = findViewById(R.id.eventDescription);
            }

        }
        // before text is changed
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        //after text is changed
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }
    }

    //Converts string to integer
    private int convertStringToInt(String string) {
        try {
            return Integer.parseInt(string);
        } catch(Exception e) {
            return 0;
        }
    }
}