package com.zybooks.daniellesousacalendarapp;


import org.junit.Before;
import org.junit.Test;
import static org.mockito.Mockito.*;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import android.content.Context;


import static org.junit.Assert.*;

public class EventDatabaseTest  {

    @Mock
    private SQLiteDatabase mockDatabase;  // Mock the SQLiteDatabase

    @Mock
    private Context mockContext;  // Mock the Context

    private EventDatabase eventDatabase;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this); // Initializes mocks

        // Mock behavior of the insert method for SQLiteDatabase
        when(mockDatabase.insert(anyString(), anyString(), any(ContentValues.class))).thenReturn(1L);

        // Create a real EventDatabase object using a mocked context and a mocked database
        eventDatabase = new EventDatabase(mockContext) {
            @Override
            public SQLiteDatabase getWritableDatabase() {
                return mockDatabase; // Return the mocked database instead of a real one
            }
        };
    }

    @Test
    public void testAddEvent() {
        // Create a new event
        Event newEvent = new Event();
        newEvent.setTitle("Test Event");
        newEvent.setDescription("Test Description");

        // Add event to the database (using the mock method)
        eventDatabase.addEvent(newEvent);

        // Verify that insert was called with correct arguments
        verify(mockDatabase, times(1)).insert(
                eq(EventDatabase.EventTable.TABLE_EVENTS), // Ensure we're inserting into the correct table
                eq(null), // Assume the second parameter is null for simplicity
                any(ContentValues.class) // Verify that a ContentValues object is passed
        );


        // Assert that the event object is not null (for a simple test)
        assertNotNull(newEvent);
    }
}