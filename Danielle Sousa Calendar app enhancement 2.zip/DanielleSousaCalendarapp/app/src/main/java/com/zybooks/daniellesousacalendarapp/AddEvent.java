package com.zybooks.daniellesousacalendarapp;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.DatePicker;
import android.widget.TimePicker;
import java.util.Calendar;

//add new event to calendar
public class AddEvent extends AppCompatActivity {

    // store events in database
    private EventDatabase mEventDb;

    //stores logged in username
    private String mUsername;

    // user interface elements event input
    private EditText mTitle;
    private DatePicker mDatePicker;
    private TimePicker mTimePicker;
    private EditText mDescription;

    private int iYear;
    private int iMonth;
    private int iDay;
    private int iHour;
    private int iMinute;




    // initializes user interface components
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.date_event_controls);

        //get username from activity
        Intent intent = getIntent();
        mUsername = intent.getStringExtra("authUsername");
        mEventDb = new EventDatabase(this);

        //initializes user interface elements
        mTitle = findViewById(R.id.tv_event_title);
        mDatePicker = findViewById(R.id.eventDatePicker);
        mTimePicker = findViewById(R.id.eventTimePicker);
        mDescription = findViewById(R.id.tv_event_description);

        Button mAddButton = findViewById(R.id.eventAddSubmit);
        Button mCancelButton = findViewById(R.id.eventCancelSubmit);

        mAddButton.setOnClickListener(this::addEvent);
        mCancelButton.setOnClickListener(this::cancelAddEvent);

        // Set TimePicker to 12-hour view programmatically

            mTimePicker.setIs24HourView(false);  // 12-hour view (AM/PM)
        

        Log.d("ButtonState", "Is Add Button clickable: " + mAddButton.isClickable());
        Log.d("ButtonState", "Is Cancel Button clickable: " + mCancelButton.isClickable());

    }

    //Add events to database
    public void addEvent(View view) {
        Log.d("AddEvent","Add button clicked");
        Toast.makeText(this, "Button Pressed", Toast.LENGTH_SHORT).show();

        iYear = mDatePicker.getYear();
        iMonth = mDatePicker.getMonth() + 1;
        iDay = mDatePicker.getDayOfMonth();
        iHour = mTimePicker.getHour();
        iMinute = mTimePicker.getMinute();



        if (!isEmpty(mTitle) && isValidDate() && !isEmpty(mDescription)) {
            Calendar mUserDate = Calendar.getInstance();
            mUserDate.set(iYear, iMonth - 1, iDay, iHour, iMinute);


            Event event = new Event(mTitle.getText().toString(), mUserDate, mDescription.getText().toString(), mUsername);
            mEventDb.addEvent(event);
            showToast("Event Added");
            finish();
        } else {
            showToast("Title and Description cannot be blank");
        }
    }

    // cancels event that is being created
    public void cancelAddEvent(View view) {
        Log.d("AddEvent", "Cancel Button clicked");
        Toast.makeText(this,"Button Pressed", Toast.LENGTH_SHORT).show();

        finish();
    }

    // verifies edit text field is empty
    public boolean isEmpty(EditText editText) {
        String text  = editText.getText().toString();
        return text.isEmpty();
    }

    // Checking each numbers length of range
    public boolean isValidDate() {
        Calendar systemTime = Calendar.getInstance();

        if (iYear < 1000 || iYear >9999) {
            showToast("Invalid Year. Needs to be 4 digits");
            return false;
        }
        if (iMonth < 1 || iMonth >12) {
            showToast("Invalid Month. Needs to be between 1-12");
            return false;
        }
        if (iDay < 1 || iDay >31) {
            showToast("Invalid Day. Needs to be between 1-31");
            return false;
        }
        if (iHour < 0 || iHour >23) {
            showToast("Invalid Hour. Needs to be between 0-23");
            return false;
        }
        if (iMinute < 0 || iMinute >59) {
            showToast("Invalid Minute. Needs to be 0-59");
            return false;
        }

        Calendar userDate = Calendar.getInstance();
        userDate.set(iYear, iMonth - 1, iDay, iHour, iMinute);
        // Checking if entered date is in the past
        if (userDate.getTimeInMillis() < systemTime.getTimeInMillis()) {
             showToast("Date cannot be before today date");
             return false;
        }
        showToast("Event has been added: " +mTitle.getText().toString());
        return true;
    }

  private void showToast(String message){
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }
}