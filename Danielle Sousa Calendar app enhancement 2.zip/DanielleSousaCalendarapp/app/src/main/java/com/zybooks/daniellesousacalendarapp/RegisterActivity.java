package com.zybooks.daniellesousacalendarapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.util.Log;


// Handles User registration
public class RegisterActivity extends AppCompatActivity {

    // database that stores user info
    private EventDatabase mEventDb;
    //User interface elements for username input
    private EditText mUsername;
    //user interface elements for password input
    private EditText mPassword;
    // error display for name already taken
    private TextView mNameNotUnique;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //Initializes user interface components
        mUsername = findViewById(R.id.usernameField);
        mPassword = findViewById(R.id.registerPasswordField);
        mNameNotUnique = findViewById(R.id.usernameNotValid);
        Button mRegisterButton = findViewById(R.id.enrollButton);

        //Get instance of database
        mEventDb = EventDatabase.getInstance(getApplicationContext());

        // set onClickListenner for registration button
        mRegisterButton.setOnClickListener( v -> {
                Log.d("RegisterActivity", "Register button clicked");
                regUser();

        });
    }

    // Confirming that name is unique and sending to Database.
       public void regUser() {
        // add comment
        Log.d("RegisterActivity", "regUser method called");
        User user = new User(mUsername.getText().toString(), mPassword.getText().toString());
        //verifies is username is unique in database
        if (!mEventDb.registerUser(user)) {
            Log.d("RegisterActivity", "Username is not unique");
            mNameNotUnique.setVisibility(View.VISIBLE); // error message
        } else {
            // hides error message
            Log.d("RegisterActivity", "Username is unique");
            mNameNotUnique.setVisibility(View.INVISIBLE);

            //registered username is sent back to previous activity
            Intent intent = new Intent();
            intent.putExtra("regUsername", user.getUsername());
            setResult(Activity.RESULT_OK, intent);
            finish();
        }
    }
}