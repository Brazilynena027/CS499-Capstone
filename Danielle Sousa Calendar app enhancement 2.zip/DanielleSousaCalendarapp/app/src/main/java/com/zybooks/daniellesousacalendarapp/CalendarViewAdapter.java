package com.zybooks.daniellesousacalendarapp;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

// Adapter for calendar recycler view
class CalendarViewAdapter extends RecyclerView.Adapter<CalendarViewHolder> {

    // list of days displayed in calendar
    private final ArrayList<String> daysOfMonth;
    // Listener for item click events
    private final OnItemListener onItemListener;

    //Constructor for calendar view adapter
    public CalendarViewAdapter(ArrayList<String> daysOfMonth, OnItemListener onItemListener) {
        this.daysOfMonth = daysOfMonth;
        this.onItemListener = onItemListener;
    }

    // view holder for calendar
    @NonNull
    @Override
    public CalendarViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.calendar_cell, parent, false);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        layoutParams.height = (int) (parent.getHeight() * 0.166666666);
        return new CalendarViewHolder(view, onItemListener);
    }

    // binds data to view holder
    @Override
    public void onBindViewHolder(@NonNull CalendarViewHolder holder, int position) {
        holder.dayOfMonth.setText(daysOfMonth.get(position));
    }

    // # of items in the calendar
    @Override
    public int getItemCount() {
        return daysOfMonth.size();
    }

    //item clicks on calendar days
    public interface OnItemListener {
        void onItemClick(int position, String dayText);
    }
}
