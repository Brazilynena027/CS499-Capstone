package com.zybooks.daniellesousacalendarapp;


import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

//View holder for a calendar in recycler view
public class CalendarViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    //OnItemListener for item clicks
    private final CalendarViewAdapter.OnItemListener onItemListener;

    // display for day of month
    public final TextView dayOfMonth;


    //Constructor Calendar view holder
    public CalendarViewHolder(@NonNull View itemView,CalendarViewAdapter.OnItemListener onItemListener) {
        super(itemView);
        dayOfMonth = itemView.findViewById(R.id.cellDayText);
        this.onItemListener = onItemListener;
        itemView.setOnClickListener(this);

    }

    //click events on calendar
    @Override
    public void onClick(View view) {
        onItemListener.onItemClick(getAdapterPosition(), (String) dayOfMonth.getText());

    }
}
