package com.zybooks.daniellesousacalendarapp;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Toast;

import java.util.Calendar;
import java.util.List;


//manages events and sms notifications
public class PermissionsActivity extends AppCompatActivity implements EventRecyclerAdapter.ItemClickListener {

    //stored events in database
    private EventDatabase mEventDb;

    //authenticated username
    private String mUsername;

    // stores events
    private List<Event> mEvents;

    // current logged in user instance
    private User user;

    //Recycler view display events
    EventRecyclerAdapter adapter;

    //Code for SMS permission
    final int REQUEST_SMS_CODE = 0;

    //String permission for SMS
    private String smsPermission = Manifest.permission.SEND_SMS;

    //system date check
    private Calendar sysTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        // Getting username for activity
        Intent intent = getIntent();
        mUsername = intent.getStringExtra("authUsername");


        //welcome message to user
        Toast myToast = Toast.makeText(this, "Welcome, " + mUsername, Toast.LENGTH_SHORT);
        myToast.show();

        // Getting events under user in Database
        mEventDb = EventDatabase.getInstance(getApplicationContext());
        user = mEventDb.getUser(mUsername);
        mEvents = mEventDb.getEvents(mUsername);

        // SMS permissions for device
        checkSMSPerms();
        smsPermission = Manifest.permission.SEND_SMS;

        // system time if current date is equal to event dates, and if yes send SMS
        sysTime = Calendar.getInstance();
        sendSMS();
    }


    // Launch ViewEvent on selected event
    public void onItemClick(View view, int position, Event event) {
        Toast.makeText(this, "You clicked ID: " + event.getTitle(), Toast.LENGTH_SHORT).show();

        //ViewEvent started with eventID that is selected
        Intent intent = new Intent(this, ViewEvent.class);
        intent.putExtra("eventId", event.getId());
        startActivity(intent);
    }

    // Launch AddEvent on button press
    public void AddEventClickListener(View view) {
        Intent intent = new Intent(this, AddEvent.class);
        intent.putExtra("authUsername", mUsername);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //list of events for user
        mEvents = mEventDb.getEvents(mUsername);

        //  recycler view for displaying events
        RecyclerView recyclerView = findViewById(R.id.calendarRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //set adapter and initializes it
        adapter = new EventRecyclerAdapter(this, mEvents);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);
    }

    //  User permissions for SMS message
    private void checkSMSPerms() {
        if (!user.smsPermAlreadyAsked()) {
            ActivityCompat.requestPermissions(this,
                    new String[]{smsPermission}, REQUEST_SMS_CODE);
            user.setSmsBool(true);
        }
    }

    //SMS reminder for events upcoming
    private void sendSMS() {

        // Send an SMS if today's date lines up with event date.

        if (!mEvents.isEmpty()) {
            for (Event event : mEvents) {
                if (!(sysTime == null))
                    if (sysTime.get(Calendar.YEAR) == event.getDate().get(Calendar.YEAR) && sysTime.get(Calendar.MONTH) == event.getDate().get(Calendar.MONTH) && sysTime.get(Calendar.DAY_OF_MONTH) == event.getDate().get(Calendar.DAY_OF_MONTH)) {
                        if (ContextCompat.checkSelfPermission(this, smsPermission)
                                == PackageManager.PERMISSION_GRANTED) {
                            String message = "Your event: " + event.getTitle() + " is due today!";
                            SmsManager smsManager = SmsManager.getDefault();
                            smsManager.sendTextMessage(getString(R.string._1234567890), null, message, null, null);
                            Toast myToast = Toast.makeText(this, message, Toast.LENGTH_LONG);
                            myToast.show();
                        }
                    }
            }
        }
    }
}

