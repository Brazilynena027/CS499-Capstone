package com.zybooks.daniellesousacalendarapp;


import androidx.annotation.NonNull;

//User in the application
public class User {

    //stores username
    private String username;
    //stores password
    private String password;
    //store sms permission by user
    private int smsBool;

    // initializes user and set the sms persion to not asked.
    public User() {
        username = null;
        password = null;
        smsBool = 3; // sms permission is being requested
    }
    // initializes the user with user set username and password
    // SMS permission is set to 3 for status of not been asked for permission yet.
    public User(String newUsername, String newPassword) {
        this.username = newUsername;
        this.password = newPassword;
        smsBool = 3;
    }

    // Gets username of user.
    public String getUsername() {

        return username;
    }

    // set username of user.
    public void setUsername(String username) {

        this.username = username;
    }

    // gets password for user.
    public String getPassword() {

        return password;
    }

    //sets password for user.
    public void setPassword(String password) {

        this.password = password;
    }

    //sets the SMS permission using a boolean. if permission is granted true if not then false.
    public void setSmsBool(boolean newSmsBool) {
        smsBool = (newSmsBool) ? 1 : 0;
    }

    //sets sms permission status with an integer for status update.
    public void setSmsBool(int newSmsBool) {
        smsBool = newSmsBool;
    }

    //Verifies if SMS permission has already been requested
    public boolean smsPermAlreadyAsked() {

        return smsBool != 3;
    }

    // returns a string with username,password and SMS status.
    @NonNull
    @Override
    public String toString() {
        return "User{username='" + username + "', password='" + password + "', smsBool=" + smsBool + "}";
    }

    //check to see if two usernames are equal
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true; //if username is same returns true
        if (obj == null || getClass() != obj.getClass()) return false; // if username not the same returns false
        User user = (User) obj;
        return username.equals(user.username); //matches one username to the other
    }

    //hash code for user object
    @Override
    public int hashCode() {
        return username.hashCode();
    }

}



