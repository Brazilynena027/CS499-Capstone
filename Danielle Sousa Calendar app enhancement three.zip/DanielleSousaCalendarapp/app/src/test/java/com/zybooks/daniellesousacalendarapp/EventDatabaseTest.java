package com.zybooks.daniellesousacalendarapp;


import org.junit.Before;
import org.junit.Test;
import static org.mockito.Mockito.*;

import android.content.ContentValues;
import net.sqlcipher.database.SQLiteDatabase;

import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;


import android.content.Context;


import static org.junit.Assert.*;

public class EventDatabaseTest  {

    @Mock
    private SQLiteDatabase mockDatabase;  // Mock the SQLiteDatabase

    @Mock
    private Context mockContext;  // Mock the Context

    private EventDatabase eventDatabase;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this); // Initializes mocks

        // Mock behavior of the insert method for SQLiteDatabase
        when(mockDatabase.insert(anyString(), anyString(), any(ContentValues.class))).thenReturn(1L);

        // Create a real EventDatabase object using a mocked context and a mocked database
        eventDatabase = new EventDatabase(mockContext) {
            @Override
            public SQLiteDatabase getWritableDatabase() {
                return (SQLiteDatabase) mockDatabase; // Return the mocked database instead of a real one

            }

            @Override
            public SQLiteDatabase getReadableDatabase() {
                return (SQLiteDatabase) mockDatabase;
            }
        };
    }

    @Test
    public void testAddEvent() {
        // Create a new event
        Event newEvent = new Event();
        newEvent.setTitle("Test Event");
        newEvent.setDescription("Test Description");

        // Add event to the database mock method
        eventDatabase.addEvent(newEvent);

        // Verify that insert was called with correct arguments
        verify(mockDatabase, times(1)).insert(
                eq(EventDatabase.EventTable.TABLE_EVENTS), // Ensure we're inserting into the correct table
                eq(null), // Assume the second parameter is null for simplicity
                any(ContentValues.class) // Verify that a ContentValues object is passed
        );


        //  ContentValues contains the correct data
        ArgumentCaptor<ContentValues> contentValuesCaptor = ArgumentCaptor.forClass(ContentValues.class);
        verify(mockDatabase).insert(eq(EventDatabase.EventTable.TABLE_EVENTS), eq(null), contentValuesCaptor.capture());

        ContentValues contentValues = contentValuesCaptor.getValue();
        assertNotNull(contentValues);
        assertEquals("Test Event", contentValues.getAsString(EventDatabase.EventTable.COL_TITLE));
        assertEquals("Test Description", contentValues.getAsString(EventDatabase.EventTable.COL_DESCRIPTION));


        // Assert that the event object is not null (for a simple test)
        assertNotNull(newEvent);
    }
}