package com.zybooks.daniellesousacalendarapp;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class DateUtils {

    private static final String DATE_FORMAT = "yyyy-MM-dd-HH:mm:ss";

    // Converts timestamp to Calendar
    public static Calendar timestampToCalendar(long timestamp) {
        if (timestamp <= 0) {
            // If the timestamp is invalid, return the current time as default
            return Calendar.getInstance();
        }

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(timestamp);
        return calendar;
    }

    // Formats a Calendar object into a string with a specified format
    public static String formatEventDate(Calendar calendar) {
        if (calendar == null) {
            // Handle null Calendar input
            throw new IllegalArgumentException("Calendar object cannot be null");
        }

        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, Locale.getDefault());
        return sdf.format(calendar.getTime());
    }
}

