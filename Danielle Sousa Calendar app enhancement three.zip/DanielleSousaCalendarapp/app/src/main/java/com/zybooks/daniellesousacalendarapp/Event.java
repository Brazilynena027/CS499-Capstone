package com.zybooks.daniellesousacalendarapp;


import java.text.DateFormat;

import java.util.Calendar;

//Event in the calendar
public class Event {

    // stores event id
    private int id;
    // stores event title
    private String title;

    //stores event date
    private Calendar date;

    //store event description
    private String description;

    // store event username
    private String eventUsername;

    //constructor
    public Event() { }

    //initializes an event with title,date,description and event username
    public Event(String newTitle, Calendar newDate, String newDescription, String newEventUsername) {

        title = newTitle;
        date = newDate;
        description = newDescription;
        eventUsername = newEventUsername;
    }

    //initializes an event with eventID,title,date,description,event username
    public Event(int newId, String newTitle, Calendar newDate, String newDescription, String newEventUsername) {
        id = newId;
        title = newTitle;
        date = newDate;
        description = newDescription;
        eventUsername = newEventUsername;
    }

    //format date as a string for event
    public String getFormattedDate() {
        DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.DEFAULT);
        return dateFormat.format(date.getTime());
    }

    //get event ID
    public int getId() {

        return id;
    }

    //Set event ID
    public void setId(int id) {

        this.id = id;
    }

    // Get event title
    public String getTitle() {

        return title;
    }

    //set event title
    public void setTitle(String title) {

        this.title = title;
    }

    // get calendar date
    public Calendar getDate() {

        return date;
    }

    //set calendar date
    public void setDate(Calendar date) {

        this.date = date;
    }

    //get event description
    public String getDescription() {

        return description;
    }

    //set event description
    public void setDescription(String description) {

        this.description = description;
    }

    // get event username
    public String getEventusername() {

        return eventUsername;
    }

    // set event username
    public void setEventusername(String eventusername) {

        this.eventUsername = eventusername;
    }
}