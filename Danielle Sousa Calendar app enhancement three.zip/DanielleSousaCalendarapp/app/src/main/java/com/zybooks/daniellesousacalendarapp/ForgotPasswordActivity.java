package com.zybooks.daniellesousacalendarapp;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

// handling the forgot password functionality
public class ForgotPasswordActivity extends AppCompatActivity{

    // user interface display for an error message when login in.
    private TextView mErrorMessage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);


        // initializing the user interface elements
        EditText mEmail = findViewById(R.id.forgotPassword);
        Button mSubmitButton = findViewById(R.id.submitButton);
        mErrorMessage = findViewById(R.id.errorMessage);

        //sets onClickListenner for the submit button
        mSubmitButton.setOnClickListener(v -> {
            String email = mEmail.getText().toString();

            // validate the email
            if (isValidEmail(email)) {
                // if the email is valid hide the error message and do a password reset
                mErrorMessage.setVisibility(View.GONE);
                resetPassword(email);

            }else {
                // if email is invalid show the error message
                mErrorMessage.setVisibility(View.VISIBLE);
                mErrorMessage.setText(R.string.enter_a_valid_email_address);
            }
        });
    }

    //Validates if email provided by user is proper format
    private boolean isValidEmail(String email) {
        //
        return email != null && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    //sends a password reset email
    private void resetPassword (String email) {
        //Displays password reset link has been sent message.
        String message = getString(R.string.error_password_reset_sent, email);
        mErrorMessage.setVisibility(View.VISIBLE);
        mErrorMessage.setText(message);
    }
}


