package com.zybooks.daniellesousacalendarapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class EventRecyclerAdapter extends RecyclerView.Adapter<EventRecyclerAdapter.ViewHolder> {

    private List<Event> Data;
    private LayoutInflater Inflater;
    private ItemClickListener ClickListener;

    EventRecyclerAdapter(Context context, List<Event> data) {
        this.Inflater = LayoutInflater.from(context);
        this.Data = data;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = Inflater.inflate(R.layout.activity_event, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Event event = Data.get(position);
        holder.EventName.setText(event.getTitle());
        holder.EventDate.setText(event.getFormattedDate());
        holder.EventId = event.getId();
    }

    @Override
    public int getItemCount() {
        return Data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private int EventId;
        TextView EventName, EventDate;

        ViewHolder(View itemView) {
            super(itemView);
            EventName = itemView.findViewById(R.id.eventName);
            EventDate = itemView.findViewById(R.id.eventDate);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (ClickListener != null) ClickListener.onItemClick(view, getAdapterPosition(), EventId);
        }
    }

    int getEvent(int id) {
        return Data.get(id).getId();
    }

    void setClickListener(ItemClickListener itemClickListener) {
        this.ClickListener = itemClickListener;
    }

    public interface ItemClickListener {
        void onItemClick(View view, int position, int eventId);
    }
}