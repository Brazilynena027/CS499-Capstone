package com.zybooks.daniellesousacalendarapp;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class CalendarActivity extends AppCompatActivity implements CalendarViewAdapter.OnItemListener{


    private TextView monthYearText;
    private RecyclerView calendarRecyclerView;
    private LocalDate selectDate;

    private AlertDialog dialog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);
        initWidgets();
        selectDate = LocalDate.now();
        setMonthView();
    }

    private void initWidgets() {

        calendarRecyclerView = findViewById(R.id.calendarRecyclerView);
        monthYearText = findViewById(R.id.monthYearTV);
    }

    private void setMonthView() {
        monthYearText.setText(monthYearFromDate(selectDate));
        ArrayList<String> daysInMonth = daysInMonthArray(selectDate);

        CalendarViewAdapter calendarAdapter = new CalendarViewAdapter(daysInMonth,  this);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(), 7);
        calendarRecyclerView.setAdapter(calendarAdapter);
        calendarRecyclerView.setLayoutManager(layoutManager);

    }

    private ArrayList<String> daysInMonthArray(LocalDate date) {
        ArrayList<String> daysInMonthArray = new ArrayList<>();
        YearMonth yearMonth = YearMonth.from(date);

        int daysinMonth = yearMonth.lengthOfMonth();
        LocalDate firstOfMonth = selectDate.withDayOfMonth(1);
        int dayOfWeek = firstOfMonth.getDayOfWeek().getValue();

        for (int i = 1; i <= 42; i++) {

            if (i <= dayOfWeek || i > daysinMonth + dayOfWeek) {
                daysInMonthArray.add("");

            } else {
                daysInMonthArray.add(String.valueOf(i + dayOfWeek));
            }
        }
        return daysInMonthArray;
    }

    private String monthYearFromDate(LocalDate date) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM yyyy");
        return date.format(formatter);
    }


    public void PreviousMonthAction(View view) {

        selectDate = selectDate.minusMonths(1);
        setMonthView();
    }

    public void NextMonthAction(View view) {
        selectDate = selectDate.plusMonths(1);
        setMonthView();
    }

    //  click event for each day of the month
    @Override
    public void onItemClick(int position, String dayText) {
        //toast for empty squares
        if(dayText.isEmpty()){
            String message = "Selected Date " + dayText + " " + monthYearFromDate(selectDate);
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
        // onClickEvents for each day of the month
        else{

            onClickEvents(dayText);
        }
    }


    // options on each day for event adding and viewing
    public void onClickEvents(String dayText) {


        String message = dayText + " " + monthYearFromDate(selectDate);


        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this, R.style.Base_Theme_DanielleSousaCalendarApp);
        final View optionsView = getLayoutInflater().inflate(R.layout.date_event_controls, null);

        dialogBuilder.setTitle(message);
        dialogBuilder.setView(optionsView);
        dialog = dialogBuilder.create();
        dialog.show();


    }

    //  user to layout for adding events for that day
    public void AddEventClickListener(View view) {
        Toast.makeText(CalendarActivity.this, "add Event", Toast.LENGTH_SHORT).show();

        dialog.cancel();

    }

    // user to layout for viewing all events for that day
    public void RemoveAllEventsClickListener(View view) {
        Toast.makeText(CalendarActivity.this, "View All Events", Toast.LENGTH_SHORT).show();
        dialog.cancel();
    }
}
